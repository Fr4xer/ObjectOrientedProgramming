//Szymon Momot CS2 Farshad Toosi
import java.security.InvalidParameterException;

public class Phone extends Product {
	private static final String v1 = "samsung";
	private static final String v2 = "apple";
	private static final String v3 = "nokia";

	private String make;
	private String model;
	private int storage;
	private String name;
	private int productID;

	public Phone(String name, String description, double price, String make, String model, int storage) {
		super(name, description, price);
		if (v1.equalsIgnoreCase(make) || v2.equalsIgnoreCase(make) || v3.equalsIgnoreCase(make)){
			this.productID = getProductID();
			this.make = make;
			this.model = model;
			this.storage = storage;
			this.name = name;
			ProductDB.add(productID, getName());
		} else {
			throw new InvalidParameterException();
		}

	}

	@Override
	public void print(){

	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getStorage() {
		return storage;
	}

	public void setStorage(int storage) {
		this.storage = storage;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getProductID() {
		return productID;
	}

	@Override
	public void setProductID(int productID) {
		this.productID = productID;
	}
}
