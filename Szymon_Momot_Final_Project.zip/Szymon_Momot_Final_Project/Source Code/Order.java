//Szymon Momot CS2 Farshad Toosi
import java.util.ArrayList;

public class Order {

    ArrayList<OrderDetails> order = new ArrayList<>();

    public void addOrder(OrderDetails oDetails) {
        order.add(oDetails);
    }

    public void remove(OrderDetails oDetails){
        order.remove(oDetails);
    }

    public void find(int find){
        order.get(find);
    }

    public void returnAll(){
        for (int i = 0; i < order.size(); i++){
            System.out.println(order.get(i));
        }
    }
}


