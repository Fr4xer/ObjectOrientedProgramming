//Szymon Momot CS2 Farshad Toosi
import java.security.InvalidParameterException;

public class TV extends Product {

    private String make;
    private String model;
    private String type;
    private String name;
    private int productID;
    private String s1 = "lcd";
    private String s2 = "led";

    public TV(String name, String description, double price, String make, String model, String type) {
        super(name, description, price);
        if (type.equalsIgnoreCase(s1) || type.equalsIgnoreCase(s2)){
            this.productID = getProductID();
            this.make = make;
            this.model = model;
            this.type = type;
            this.name = name;
            ProductDB.add(productID, getName());
        } else {
            throw new InvalidParameterException();
        }

    }

    @Override
    public void print(){


    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getProductID() {
        return productID;
    }

    @Override
    public void setProductID(int productID) {
        this.productID = productID;
    }
}



