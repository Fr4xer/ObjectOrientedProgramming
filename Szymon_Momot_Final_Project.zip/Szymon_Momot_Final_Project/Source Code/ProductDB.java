//Szymon Momot CS2 Farshad Toosi
import java.util.HashMap;

public class ProductDB {
	static HashMap<Integer, String> ProductDB = new HashMap<>();

	public static void add(int productID, String productName) {
		ProductDB.put(productID, productName);
	}

	public static void remove(int ProductID, String productName) {
		ProductDB.remove(ProductID, productName);
	}

	public static String find(int ProductID){
		String find = ProductDB.get(ProductID);
		return find;
	}

	public static void returnAll(){
		System.out.println(ProductDB);
	}

}
