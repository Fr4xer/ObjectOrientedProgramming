//Szymon Momot CS2 Farshad Toosi
public class test {
	public static void main(String[] args) {
		Phone p1 = new Phone("Iphone 13", "The newest Iphone", 1100, "Apple", "13", 256);
		Phone p2 = new Phone("Nokia 250", "The newest Nokia", 300, "Nokia", "250", 64);
		Phone p3 = new Phone("Galaxy S10", "The samsung phone", 1050, "Samsung", "Galaxy S10", 124);
		Phone p4 = new Phone("Galaxy S8", "The Samsung galaxy S8 phone", 3000, "Samsung", "Galaxy S8", 64);

		TV T1 = new TV("LG Smart TV 600", "The newest smart tv from LG", 1200, "LG", "LG600", "LED");
		TV T2 = new TV("Samsung Smart TV S120", "The newest smart tv from Samsung", 800, "Samsung", "S120", "LCD");
		TV T3 = new TV("LG Smart TV 400", "smart tv from LG", 950, "LG", "LG400", "LED");

		OrderDetails a = new OrderDetails(p2, 5);
		OrderDetails b = new OrderDetails(T1, 2);
		OrderDetails c = new OrderDetails(T3, 1);

		Order Order1 = new Order();
		Order1.addOrder(a);
		Order1.addOrder(b);
		Order1.addOrder(c);

		Customer customer1 = new Customer("Jack", "11 AppleDrive", Order1);
		ProductDB.returnAll();
	}
}
