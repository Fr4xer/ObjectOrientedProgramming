//Szymon Momot CS2 Farshad Toosi
class Product {
	private static int count = 0;
	private int ProductID;
	private String name;
	private String description;
	private double price;

	public Product(String name, String description, double price){
		setProductID(++count);
		this.name = name;
		this.description = description;
		this.price = price;
		ProductDB.add(ProductID, getName());
	}

	public void print(){

	}

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Product.count = count;
	}

	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}
