//Szymon Momot CS2 Farshad Toosi
import java.util.ArrayList;

public class Customer {
    private String name;
    private String address;
    ArrayList<Order> orders = new ArrayList<>();

    public Customer(String name, String address, Order o) {
        this.name = name;
        this.address = address;
    }

    public void addOrder(Order o){
        orders.add(o);

    }

    public void removeOrder(Order o){
        orders.remove(o);
    }

    public void findOrder(int i){
        orders.get(i);
    }

    public void showAll(){
        for (int i = 0; i < orders.size(); i++){
            System.out.println(orders.get(i));
        }
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
